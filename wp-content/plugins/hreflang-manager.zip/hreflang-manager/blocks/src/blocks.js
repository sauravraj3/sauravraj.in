/**
 * All blocks should be included here since this is the file that Webpack is compiling as the entry point.
 */

//Import the "Hreflang Manager" sidebar implemented with the Sidebar API
import './hreflang-manager/index.js';